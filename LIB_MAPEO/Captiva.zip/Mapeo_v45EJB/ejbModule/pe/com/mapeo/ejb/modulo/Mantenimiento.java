package pe.com.mapeo.ejb.modulo;

import java.util.HashMap;
import java.util.Map;

import javax.ejb.Stateless;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import pe.com.mapeo.dao.Jpo;
import pe.com.mapeo.dao.Tabla;
import pe.com.mapeo.ejb.controller.GestionBase;

@Stateless
public class Mantenimiento extends GestionBase implements MantenimientoLocal {

	public Object registrar(Jpo jpo, HttpServletRequest request,HttpServletResponse response) throws Exception {
		if(request.getParameter("registrarTodo") == null){
			return jpo.tabla("Mantenimiento","MAN").registrar();
		} else {
			jpo.autoCommit(false);
				Tabla mantenimiento = jpo.tabla("Mantenimiento","MAN");
					mantenimiento.registrar();
				Tabla mantenimientoRoles = jpo.tabla("MantenimientoRoles","MRO");
					mantenimientoRoles.registrarMultiple();
				Tabla atributos = jpo.tabla("MantenimientoAtributo","AMA");
					atributos.registrarMultiple();
			jpo.commitear();
			return true;
		}
	}
	
	public Object eliminar(Jpo jpo, HttpServletRequest request,HttpServletResponse response) throws Exception {
		return jpo.tabla("Mantenimiento","MAN").eliminar();
	}
	
	public Object listar(Jpo jpo, HttpServletRequest request,HttpServletResponse response) throws Exception {
		return jpo.tabla("Mantenimiento","MAN").seleccionar("codigoMantenimiento,nombre,descripcion,codigoEsquema,codigoDataSource");
	}
	
	public Object editarCargar(Jpo jpo, HttpServletRequest request,HttpServletResponse response) throws Exception {
		Map<String,Object> carga = new HashMap<String,Object>();
		carga.put("mantenimiento", jpo.tabla("Mantenimiento","MAN").obtener("*"));
		carga.put("mantenimientoAtributo", jpo.tabla("MantenimientoAtributo","MAN").seleccionar("*"));
		carga.put("MantenimientoRoles", jpo.tabla("MantenimientoRoles","MAN").seleccionar("*"));
		return carga;
	}
	
	public Object editar(Jpo jpo, HttpServletRequest request,HttpServletResponse response) throws Exception {
		if(((Boolean) jpo.tabla("Mantenimiento","MAN").editar())){
			
			Tabla mantenimientoRoles = jpo.tabla("MantenimientoRoles","MRO");
			if(((Boolean) mantenimientoRoles.eliminar())){
				mantenimientoRoles.registrarMultiple();
			}
			
			Tabla atributos = jpo.tabla("MantenimientoAtributo","AMA");
			if(((Boolean) atributos.eliminar())){
				atributos.registrarMultiple();
			}
			return true;
		} else {
			return false;
		}
		
	}

}