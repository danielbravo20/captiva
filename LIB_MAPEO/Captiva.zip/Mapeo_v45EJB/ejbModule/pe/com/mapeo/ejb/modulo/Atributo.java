package pe.com.mapeo.ejb.modulo;

import javax.ejb.Stateless;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import pe.com.mapeo.dao.Jpo;
import pe.com.mapeo.dao.Tabla;
import pe.com.mapeo.ejb.controller.GestionBase;

@Stateless
public class Atributo extends GestionBase implements AtributoLocal {

	public Object registrar(Jpo jpo, HttpServletRequest request,HttpServletResponse response) throws Exception {
		return jpo.tabla("Atributo","ATR").registrar();
	}
	
	public Object editarCargar(Jpo jpo, HttpServletRequest request,HttpServletResponse response) throws Exception {
		return jpo.tabla("Atributo","ATR").ordenadoPor("orden ASC").seleccionar("*");
	}
	
	public Object editar(Jpo jpo, HttpServletRequest request,HttpServletResponse response) throws Exception {
		Tabla atributos = jpo.tabla("Atributo","ATR");
		if(((Boolean) atributos.eliminar())){
			atributos.registrarMultiple();
		}
		return true;
	}
	
	public Object eliminar(Jpo jpo, HttpServletRequest request,HttpServletResponse response) throws Exception {
		return jpo.tabla("Atributo","ATR").eliminar();
	}

	public Object listar(Jpo jpo, HttpServletRequest request,HttpServletResponse response) throws Exception {
		return jpo.tabla("Atributo","ATR").ordenadoPor("orden ASC").seleccionar("codigoAtributo,java_esAtributo,java_atributo,proceso_esAtributo,proceso_atributo,bds_esAtributo,bds_atributo,esTipoDatoEntidad,codigoClase");
	}
	
	public Object listaAtributoxPK(Jpo jpo, HttpServletRequest request,HttpServletResponse response) throws Exception {
		return jpo.tabla("Atributo","ATR").ordenadoPor("orden ASC").seleccionar("codigoAtributo,codigoClase,bds_atributo");
	}
	
}