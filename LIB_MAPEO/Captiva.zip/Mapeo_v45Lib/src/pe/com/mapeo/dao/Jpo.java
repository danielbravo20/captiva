package pe.com.mapeo.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import com.google.gson.Gson;

public class Jpo {
	/*
	private String tipo = "SQLITE";
	private String jdbcClassName = "org.sqlite.JDBC";
	private  String url = "jdbc:sqlite:\\\\OHUERTASP\\Compartido\\Mapeov4.db";
	*/
	private String tipo = "DB2";
	private String jdbcClassName = "com.ibm.db2.jcc.DB2Driver";
	private String url = "jdbc:db2://SDB2BPMBFDES01:50000/BFP_NEXO:retrieveMessagesFromServerOnGetMessage=true;";
	private String user = "usr_nexo";
	private String password = "usr_nexo";
	
	/* ESQUEMA DEFECTO - Vacio no se adiciona*/
	// private String esquema = "";
	private String esquema = "BFP_CARTA_FIANZA";
	
	private Map<String,Object> data = new HashMap<String,Object>();
	private Map<String,Object> dataTipo = new HashMap<String,Object>();
	private Map<String,Object> dataMultiple = new HashMap<String,Object>();
	
	private Connection c = null;
	
	public Connection getConexion(boolean autoCommit){
	    try {
	    	Class.forName(jdbcClassName);
	    	if(tipo.equals("SQLITE")){
	    		c = DriverManager.getConnection(url);
	    	}
	    	if(tipo.equals("DB2")){
	    		c = DriverManager.getConnection(url, user, password);
	    	}
	    	System.out.println("Conectado a 'Mapeov4' correctamente en : "+url);

	    	c.setAutoCommit(autoCommit);
		} catch ( Exception e ) {
			System.err.println(e.getClass().getName() + ": " + e.getMessage());
			System.err.println("ERROR AL CONECTARSE A LA BASE DE DATOS :");
			e.printStackTrace();
		}
	    return c;
	}
	
	public void autoCommit(boolean autoCommit) throws SQLException{
		if(c!=null){
			c.setAutoCommit(autoCommit);
		}
	}
	
	private void instanciarJpo(HttpServletRequest request,boolean autoCommit) throws Exception {
		
		getConexion(autoCommit);
		
		try {
			Enumeration keys = request.getParameterNames();  
			while(keys.hasMoreElements()){  
				String llave = (String)keys.nextElement();
				String value = new String(request.getParameter(llave).getBytes("ISO-8859-1"), "UTF-8");

				///System.out.println(" - llave = |"+llave+"| , value= |"+value+"|");
				
				String[] valores = llave.split("_");
				
				// "EJE_F_CODIGO_SOLICITUD"
				if(valores.length>=3 && valores[0].length()==3 && valores[1].length()==1){
					//System.out.println("   --> Es Referencia y Tipo");
					
					String Referencia = valores[0];
					String Tipo = valores[1];
					String llaveOriginal = llave.substring(6);
					
					if(Tipo.equals("M")){// "EJE_M_23_Codigo
						
						String[] Indices = llaveOriginal.split("_");
						
						String indice = Indices[0];
						llaveOriginal = llaveOriginal.substring((Indices[0].length()+1));
						
						Map<String,Object> listaIndices = null;
						if(dataMultiple.get(Referencia) == null){
							listaIndices = new HashMap<String,Object>();
						} else {
							listaIndices = (Map<String, Object>) dataMultiple.get(Referencia);
						}
						
						Map<String,String> listaParametros = null;
						if(listaIndices.get(indice) == null){
							listaParametros = new LinkedHashMap<String,String>();
						} else {
							listaParametros = (Map<String, String>) listaIndices.get(indice);
						}
						
						listaParametros.put(llaveOriginal, value);
						listaIndices.put(indice, listaParametros);
						
						dataMultiple.put(Referencia, listaIndices);
						
					} else {
						Map<String,Object> listaTipos = null;
						if(dataTipo.get(Referencia) == null){
							listaTipos = new LinkedHashMap<String,Object>();
						} else {
							listaTipos = (Map<String, Object>) dataTipo.get(Referencia);
						}
						
						Map<String,String> listaParametros = null;
						if(listaTipos.get(Tipo) == null){
							listaParametros = new LinkedHashMap<String,String>();
						} else {
							listaParametros = (Map<String, String>) listaTipos.get(Tipo);
						}
						listaParametros.put(llaveOriginal, value);
						listaTipos.put(Tipo, listaParametros);
						dataTipo.put(Referencia, listaTipos);
					}
					
				// "EJE_CODIGO_SOLICITUD"
				} else if(valores.length>=2 && valores[0].length()==3){
					//System.out.println("   --> Es Referencia");
					String Referencia = valores[0];
					String llaveOriginal = llave.substring(4);
					//System.out.println("   --> |"+Referencia+"|"+llaveOriginal+"|");
					Map<String,String> listaParametros = null;
					if(data.get(Referencia) == null){
						listaParametros = new LinkedHashMap<String,String>();
					} else {
						listaParametros = (Map<String, String>) data.get(Referencia);
					}
					listaParametros.put(llaveOriginal, value);
					data.put(Referencia, listaParametros);
				}
				
			}
			
			Gson json = new Gson();
			/*
			System.out.println("INICIA JPO");
			
			System.out.println("\n\n");
			System.out.println(json.toJson(data));
			System.out.println(json.toJson(dataTipo));
			System.out.println(json.toJson(dataMultiple));
			*/
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Error parsear Data");
		}
	}
	
	public Jpo(HttpServletRequest request) throws Exception {
		instanciarJpo(request,false);
	}
	
	public Jpo(HttpServletRequest request,boolean autoCommit) throws Exception {
		instanciarJpo(request,autoCommit);
	}
	
	@Override
	protected void finalize() throws Throwable {
		super.finalize();
	}
	
	public Tabla tabla(String nombreTabla,String Referencia){
		return new Tabla(c,((esquema.equals(""))?"":esquema+".")+nombreTabla,data.get(Referencia),dataMultiple.get(Referencia),dataTipo.get(Referencia));
	}
	
	public Tabla tabla(String nombreTabla){
		return new Tabla(c,((esquema.equals(""))?"":esquema+".")+nombreTabla,null,null,null);
	}
	
	public void commitear() throws SQLException{
		if(c != null){
			if(!c.getAutoCommit()){
				c.commit();
			}
		}
	}
	
	public void finalizar() throws SQLException{
		if(c != null){
			c.close();
		}
	}
	
}