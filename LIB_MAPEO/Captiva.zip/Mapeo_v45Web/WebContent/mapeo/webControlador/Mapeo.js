﻿var getParametro = Core.getQueryString();

var reglaMapeo = function(datos){
	var incorrectas = 0;
	var respuesta = {
		resultado : false,
		mensaje : ""
	};
	for(var i in datos){
		var campo = datos[i];
		if(campo.regla=="REQUERIDO"){
			if(typeof(campo.valor)=="undefined"){
				respuesta.mensaje = campo.mensaje;
				incorrectas++;
				break;
			} else {
				if(typeof(campo.valor)=="object"){
					if(Object.size(respuesta)==0){
						respuesta.mensaje = campo.mensaje;
						incorrectas++;
						break;
					}
				} else {
					if(campo.valor.length==0){
						respuesta.mensaje = campo.mensaje;
						incorrectas++;
						break;
					}
				}
			}
		}
		if(campo.regla=="ENTERO"){
			if (!/^\+?([1-9]\d*)$/.test(campo.valor)){
				respuesta.mensaje = campo.mensaje;
				incorrectas++;
				break;
			}
		}
	}
	if(incorrectas==0){
		respuesta.resultado = true;
	}
	return respuesta;
};

var Mapeo = {};

	Mapeo.data = {
		perfil : [
			{ id: "PRO_MAN", valor: "GESTOR DE PROYECTOS"},
			{ id: "LID_TEC", valor: "LIDER TÉCNICO"},
			{ id: "ANA_PRO", valor: "ANALISTA PROGRAMADOR"}
		]
	};

var principal = angular.module('principal', ['ui.bootstrap']);

	principal.controller("menu", function($scope, $http, $timeout, $modal, datepickerPopupConfig) {
		
		// FECHA
		datepickerPopupConfig.closeText = 'Cerrar';
		datepickerPopupConfig.currentText = 'Hoy';
		datepickerPopupConfig.clearText = 'Limpiar';
		$scope.fecha = {
			formato : "yyyy-MM-dd",
			abierto : {},
			abrir : function($event,tipo) {
				$event.preventDefault();
				$event.stopPropagation();
				$scope.fecha.abierto[tipo] = true;
			}
		};

		$scope.modulo = 'proyecto'; // proyecto - usuario - unidadNegocio - trabajarProyecto - esquema - dataSource - rol
		$scope.subModulo = ''; // trabajarProyecto : { modulosProyecto, generarProyecto, esquema, dataSource, rol};
		$scope.data = {
			Proyecto : {esCargado : false}
		};
		$scope.combo = {
			Perfil : Mapeo.data.perfil
		};
		
		$scope.getComboxId = function(nombreCombo,buscar,id,valor){
			if(!id){id = "id";} if(!valor){valor = "valor";}
			for(var i in $scope.combo[nombreCombo]){
				if($scope.combo[nombreCombo][i][id] == buscar){
					return $scope.combo[nombreCombo][i][valor];
				}
			}
		};
		
		$scope.cargarUsuario = function(usuario,callback){
			var dataReq = { paquete: "gestion", modulo: "Usuario", metodo: "cargarUsuario"};
			Core.ajax($http,dataReq,{USU_W_COD_USUARIO : usuario},function(respuesta){
				$scope.data.USUARIO = respuesta;
				// Instanciar Componentes
				angular.element(document.querySelector('[ng-controller=perfilUsuario]')).scope().peu.instanciar();
				if(callback){ callback();}
			});
		};
		
		$scope.cargarProyecto = function(){
			var dataReq = { paquete: "gestion", modulo: "Principal", metodo: "listarProyectos"};
			Core.ajax($http,dataReq,{EQU_W_COD_USUARIO : $scope.data.USUARIO.COD_USUARIO},function(respuesta){
			
				var proyectoId = [];
				for(var i in respuesta.PROYECTOS){
					proyectoId[respuesta.PROYECTOS[i].COD_PROYECTO] = i;
					respuesta.PROYECTOS[i].equipo = [];
					respuesta.PROYECTOS[i].versiones = [];
				}
				for(var i in respuesta.USUARIOxProyectos){
					if(respuesta.USUARIOxProyectos[i].esResponsable && respuesta.USUARIOxProyectos[i].COD_USUARIO == $scope.data.USUARIO.COD_USUARIO){
						$scope.data.USUARIO.esResponsable = true;
					}
					respuesta.PROYECTOS[proyectoId[respuesta.USUARIOxProyectos[i].COD_PROYECTO]].equipo.push(respuesta.USUARIOxProyectos[i]);
				}
				for(var i in respuesta.Versiones){
					respuesta.PROYECTOS[proyectoId[respuesta.Versiones[i].COD_PROYECTO]].versiones.push(respuesta.Versiones[i]);
				}
				angular.extend($scope.data, respuesta);
				
				// Instanciar Componentes
				angular.element(document.querySelector('[ng-controller=gestionarProyecto]')).scope().pro.instanciar();
				angular.element(document.querySelector('[ng-controller=gestionarUsuario]')).scope().usu.instanciar();
				angular.element(document.querySelector('[ng-controller=gestionarUnidadNegocio]')).scope().une.instanciar();
				angular.element(document.querySelector('[ng-controller=gestionarUnidadNegocio]')).scope().une.instanciar();
				
				
				
				if(getParametro.proyecto && getParametro.version && getParametro.unidadNegocio){
					respuesta.PROYECTOS[proyectoId[getParametro.proyecto]].versionSeleccionada = getParametro.version;
					respuesta.PROYECTOS[proyectoId[getParametro.proyecto]].unidadNegocioSeleccionado = getParametro.unidadNegocio;
					$scope.cargarTrabajarProyecto(respuesta.PROYECTOS[proyectoId[getParametro.proyecto]]);
				}
				
			});
		};
		
		$scope.cargarTrabajarProyecto = function(objetoProyecto){
		
     		$scope.data.PROYECTO = objetoProyecto;
			$scope.data.PROYECTO.esCargado = true;
			$scope.modulo = "trabajarProyecto";
			$scope.subModulo = "modulosProyecto";
		
			var dataReq = { paquete: "gestion", modulo: "Principal", metodo: "listarRegistros"};
			Core.ajax($http,dataReq,{
				LIB_W_COD_PROYECTO 	: $scope.data.PROYECTO.COD_PROYECTO,
				LIS_W_COD_PROYECTO 	: $scope.data.PROYECTO.COD_PROYECTO,
				LIS_W_COD_VERSION 	: $scope.data.PROYECTO.versionSeleccionada,
				LIC_W_COD_PROYECTO 	: $scope.data.PROYECTO.COD_PROYECTO,
				LIC_W_COD_USUARIO 	: $scope.data.USUARIO.COD_USUARIO
			},function(respuesta){
				angular.extend($scope.data, respuesta);
				// Instanciar Componentes
				
				angular.element(document.querySelector('[ng-controller=proyectoActual]')).scope().pra.instanciar();
				angular.element(document.querySelector('[ng-controller=esquema]')).scope().esq.instanciar();
				angular.element(document.querySelector('[ng-controller=dataSource]')).scope().dso.instanciar();
				angular.element(document.querySelector('[ng-controller=rol]')).scope().rol.instanciar();

				angular.element(document.querySelector('[ng-controller=entidad]')).scope().ent.instanciar();
				angular.element(document.querySelector('[ng-controller=mantenimiento]')).scope().man.instanciar(false);
				

			});
			
		};
		
		if(getParametro.usuario){
			$scope.cargarUsuario(getParametro.usuario,$scope.cargarProyecto);
		} else {
			$scope.cargarProyecto();
		};
		
		$scope.alertas = [];
		$scope.agregarAlerta = function(tipo,mensaje){
			$scope.alertas.push({tipo: tipo,mensaje: mensaje});
			var pos = $scope.alertas.length-1;
			$timeout(function(){
				$scope.alertas.splice(pos,1);
			},3000);
		};
		$scope.cerrarAlerta = function(index) {
			$scope.alertas.splice(index, 1);
		};
		
		$scope.abrirGenerador = function(){
			var modalInstance = $modal.open({
				animation: true,
				templateUrl: 'Generar.html',
				controller: 'Modal_generar',
				resolve: {
					config : function(){
						return {
							data : $scope.data
						};
					}
				}
			});
			modalInstance.result.then(function(){
				$scope.instanciar();
			});
		};
		
		$scope.generar = function(){
			
		}
		
	});
	
	principal.controller("gestionarUsuario", function($scope, $http) {
		
		$scope.usu = {};
		
		$scope.usu.instanciar = function(listar){
			$scope.usu.cargado = { paquete : "gestion", modulo : "Usuario"};
			$scope.usu.esEdicion = false;
			if(typeof(listar)!="undefined"){
				if(listar){
					$scope.usu.listar();
				}
			}
		};
		
		$scope.usu.listar = function(){
			$scope.usu.cargado.metodo = "listar";
			Core.jpo($http,$scope.usu.cargado,function(respuesta){
				$scope.$parent.data.USUARIOs = respuesta;
			});
		};
		
		$scope.usu.eliminar = function(index){
			if(confirm("Desea eliminar el Usuario seleccionado?")){
				$scope.usu.cargado.metodo = "eliminar";
				$scope.usu.cargado.USU_W_COD_USUARIO = $scope.data.USUARIOs[index].COD_USUARIO;	// WHERE-------
				Core.jpo($http,$scope.usu.cargado,function(respuesta){
					delete $scope.usu.cargado.USU_W_COD_USUARIO;									// WHERE-------
					$scope.agregarAlerta("success","Usuario eliminado corréctamente");
					$scope.usu.instanciar(true);
				});
			}
		};
		
		$scope.usu.editarCargar = function(index){
			$scope.usu.cargado.USU_COD_USUARIO = $scope.data.USUARIOs[index].COD_USUARIO;		// VAL-------
			$scope.usu.cargado.USU_nombre = $scope.data.USUARIOs[index].nombre;						// VAL-------
			$scope.usu.cargado.USU_perfil = $scope.data.USUARIOs[index].perfil;						// VAL-------
			$scope.usu.cargado.USU_descripcion = $scope.data.USUARIOs[index].descripcion;			// VAL-------
			$scope.usu.esEdicion = true;
		};
		
		$scope.validarClave = function(callback){
			$scope.usu.cargado.metodo = "consultarClave";
			$scope.usu.cargado.USU_W_COD_USUARIO = $scope.usu.cargado.USU_COD_USUARIO;		// WHERE-------
			Core.jpo($http,$scope.usu.cargado,function(respuesta){
				if(Object.size(respuesta)>0){
					if(callback){callback();}
				} else {
					$scope.agregarAlerta("danger","La contraseña anterior es incorrecta");
				}
			});
		};
		
		$scope.usu.guardar = function(){
			if($scope.usu.esEdicion){
				$scope.validarClave(function(){
					$scope.usu.cargado.metodo = "editar";
					Core.jpo($http,$scope.usu.cargado,function(respuesta){
						delete $scope.usu.cargado.USU_W_COD_USUARIO;									// WHERE-------
						$scope.agregarAlerta("success","Usuario editado corréctamente");
						$scope.usu.instanciar(true);
					});
				});
			} else {
				$scope.usu.cargado.metodo = "registrar";
				Core.jpo($http,$scope.usu.cargado,function(respuesta){
					$scope.agregarAlerta("success","Usuario creado corréctamente");
					$scope.usu.instanciar(true);
				});
			}
		};
		
	});
	
	principal.controller("gestionarUnidadNegocio", function($scope, $http) {

		$scope.une = {};
		
		$scope.une.instanciar = function(listar){
			$scope.une.cargado = { paquete : "gestion", modulo : "UnidadNegocio"};
			$scope.une.esEdicion = false;
			if(typeof(listar)!="undefined"){
				if(listar){
					$scope.une.listar();
				}
			}
		};
		
		$scope.une.listar = function(){
			$scope.une.cargado.metodo = "listar";
			Core.jpo($http,$scope.une.cargado,function(respuesta){
				$scope.$parent.data.UnidadesNegocio = respuesta;
			});
		};
		
		$scope.une.eliminar = function(index){
			if(confirm("Desea eliminar la unidad de negocio seleccionada?")){
				$scope.une.cargado.metodo = "eliminar";
				$scope.une.cargado.UNE_W_codigoUnidadNegocio = $scope.data.UnidadesNegocio[index].codigoUnidadNegocio;	// WHERE-------
				Core.jpo($http,$scope.une.cargado,function(respuesta){
					delete $scope.une.cargado.UNE_W_codigoUnidadNegocio;												// WHERE-------
					$scope.agregarAlerta("success","Unidad de negocio eliminado corréctamente");
					$scope.une.instanciar(true);
				});
			}
		};
		
		$scope.une.editarCargar = function(index){
			$scope.une.cargado.UNE_codigoUnidadNegocio = $scope.data.UnidadesNegocio[index].codigoUnidadNegocio;	// VAL-------
			$scope.une.cargado.UNE_descripcion = $scope.data.UnidadesNegocio[index].descripcion;					// VAL-------
			$scope.une.esEdicion = true;
		};
		
		$scope.une.guardar = function(){
			if($scope.une.esEdicion){
				$scope.une.cargado.metodo = "editar";
				$scope.une.cargado.UNE_W_codigoUnidadNegocio = $scope.une.cargado.UNE_codigoUnidadNegocio;	// WHERE-------
				Core.jpo($http,$scope.une.cargado,function(respuesta){
					delete $scope.une.cargado.UNE_W_codigoUnidadNegocio;									// WHERE-------
					$scope.agregarAlerta("success","Unidad de negocio editado corréctamente");
					$scope.une.instanciar(true);
				});
			} else {
				$scope.une.cargado.metodo = "registrar";
				Core.jpo($http,$scope.une.cargado,function(respuesta){
					$scope.agregarAlerta("success","Unidad de negocio creado corréctamente");
					$scope.une.instanciar(true);
				});
			}
		};
	
	});
	
	principal.controller("perfilUsuario", function($scope, $http) {

		$scope.peu = {
			cargado : {}
		};

		$scope.peu.instanciar = function(){
			$scope.peu.cargado = { 
				paquete : "gestion", 
				modulo : "Usuario",
				USU_W_COD_USUARIO : $scope.data.USUARIO.COD_USUARIO,
				USU_nombre : $scope.data.USUARIO.nombre,
				USU_descripcion : $scope.data.USUARIO.descripcion
			};
		};

		$scope.validarClave = function(callback){
			$scope.peu.cargado.metodo = "consultarClave";
			Core.jpo($http,$scope.peu.cargado,function(respuesta){
				if(Object.size(respuesta)>0){
					if(callback){callback();}
				} else {
					$scope.agregarAlerta("danger","La contraseña anterior es incorrecta");
				}
			});
		};

		$scope.peu.guardar = function(){
			$scope.validarClave(function(){
				$scope.peu.cargado.metodo = "editar";
				Core.jpo($http,$scope.peu.cargado,function(respuesta){
					$scope.agregarAlerta("success","Perfil editado corréctamente");
				});
			});
		};

	});
	
	principal.controller("gestionarProyecto", function($scope, $http) {

		$scope.pro = {};
		
		$scope.pro.instanciar = function(listar){
			$scope.pro.cargado = { paquete : "modulo", modulo : "Proyecto"};
			$scope.pro.USUARIOs = angular.copy($scope.data.USUARIOs);
			$scope.pro.vista = 'lista';
			$scope.pro.esEdicion = false;
			if(listar){
				$scope.$parent.cargarProyecto();
			}
		};
		
		$scope.pro.trabajar = function(index){
			$scope.$parent.cargarTrabajarProyecto($scope.data.PROYECTOS[index]);
			/*if($scope.data.PROYECTOS[index].versionSeleccionada && $scope.data.PROYECTOS[index].versionSeleccionada!=""){
				var versel = $scope.data.PROYECTOS[index].versiones[$scope.data.PROYECTOS[index].versionSeleccionada];
				$scope.data.PROYECTOS[index].versionSeleccionada = versel.numeroVersion;
				$scope.data.PROYECTOS[index].unidadNegocioSeleccionado = versel.codigoUnidadNegocio;
				$scope.$parent.cargarTrabajarProyecto($scope.data.PROYECTOS[index]);
			} else {
				$scope.agregarAlerta("danger","Selecciona una versión");
			}*/
		};
		
		$scope.pro.editarCargar = function(index){
			$scope.pro.cargado.PRO_COD_PROYECTO 	= $scope.data.PROYECTOS[index].COD_PROYECTO;		// VAL-------
			$scope.pro.cargado.PRO_nombre 			= $scope.data.PROYECTOS[index].nombre;				// VAL-------
			$scope.pro.cargado.PRO_descripcion 		= $scope.data.PROYECTOS[index].descripcion;			// VAL-------
			$scope.pro.cargado.PRO_estado 			= $scope.data.PROYECTOS[index].estado;				// VAL-------
			$scope.pro.cargado.PRO_fechaCreacion 	= $scope.data.PROYECTOS[index].fechaCreacion;		// VAL-------
			$scope.pro.cargado.PRO_fechaFinalizacion= $scope.data.PROYECTOS[index].fechaFinalizacion;	// VAL-------
			$scope.pro.cargado.versiones 			= $scope.data.PROYECTOS[index].versiones;
			var usuarioId = [];
			for(var i in $scope.pro.USUARIOs){
				usuarioId[$scope.pro.USUARIOs[i].COD_USUARIO] = i;
			}
			for(var i in $scope.data.PROYECTOS[index].equipo){
				var equipo = $scope.data.PROYECTOS[index].equipo[i];
				$scope.pro.USUARIOs[usuarioId[equipo.COD_USUARIO]].esDelEquipo = true;
				$scope.pro.USUARIOs[usuarioId[equipo.COD_USUARIO]].CARPETA_DESTINO_WORKSPACE = equipo.CARPETA_DESTINO_WORKSPACE;
				$scope.pro.USUARIOs[usuarioId[equipo.COD_USUARIO]].CARPETA_DESTINO_PARCIAL = equipo.CARPETA_DESTINO_PARCIAL;
				if(equipo.esResponsable){
					$scope.pro.cargado.USUARIOResponsable = equipo.COD_USUARIO;
				}
			}
			$scope.pro.esEdicion = true;
			$scope.pro.vista = 'mantener';
		};
		
		$scope.pro.nuevoCargar = function(index){
			$scope.pro.instanciar();
			$scope.pro.vista = 'mantener';
		};
		
		$scope.pro.guardar = function(){
			var cont = 1;
			for(var i in $scope.pro.USUARIOs){
				var user = $scope.pro.USUARIOs[i];
				if(user.esDelEquipo){
					$scope.pro.cargado["EQU_M_"+cont+"_COD_USUARIO"] = user.COD_USUARIO;
					$scope.pro.cargado["EQU_M_"+cont+"_COD_PROYECTO"] = $scope.pro.cargado.PRO_COD_PROYECTO;
					$scope.pro.cargado["EQU_M_"+cont+"_esResponsable"] = ($scope.pro.cargado.USUARIOResponsable==user.COD_USUARIO)?1:0;
					if($scope.pro.esEdicion){
					$scope.pro.cargado["EQU_M_"+cont+"_CARPETA_DESTINO_WORKSPACE"] = user.CARPETA_DESTINO_WORKSPACE;
					$scope.pro.cargado["EQU_M_"+cont+"_CARPETA_DESTINO_PARCIAL"] = user.CARPETA_DESTINO_PARCIAL;
					}
					cont++
				}
			}
			if($scope.pro.esEdicion){
				$scope.pro.cargado.metodo = "editar";
				$scope.pro.cargado.PRO_W_COD_PROYECTO = $scope.pro.cargado.PRO_COD_PROYECTO;	// WHERE-------
				$scope.pro.cargado.EQU_W_COD_PROYECTO = $scope.pro.cargado.PRO_COD_PROYECTO;	// WHERE-------
				Core.jpo($http,$scope.pro.cargado,function(respuesta){
					delete $scope.pro.cargado.PRO_W_COD_PROYECTO;									// WHERE-------
					delete $scope.pro.cargado.EQU_W_COD_PROYECTO;									// WHERE-------
					$scope.agregarAlerta("success","Esquema editado corréctamente");
					$scope.pro.instanciar(true);
				});
			} else {
				$scope.pro.cargado.metodo = "registrar";
				$scope.pro.cargado.VER_COD_VERSION	= 1;
				$scope.pro.cargado.VER_COD_PROYECTO 	= $scope.pro.cargado.PRO_COD_PROYECTO;
				Core.jpo($http,$scope.pro.cargado,function(respuesta){
					$scope.agregarAlerta("success","Proyecto creado corréctamente");
					$scope.pro.instanciar(true);
				});
			}
		};
		
		$scope.pro.eliminar = function(index){
			if(confirm("Confirma eliminar el seleccionado?")){
				$scope.pro.cargado.metodo = "eliminar";
				$scope.pro.cargado.PRO_W_COD_PROYECTO = $scope.pro.cargado.PRO_COD_PROYECTO;	// WHERE-------
				Core.jpo($http,$scope.pro.cargado,function(respuesta){
					delete $scope.pro.cargado.PRO_W_COD_PROYECTO;									// WHERE-------
					$scope.agregarAlerta("success","Proyecto eliminado corréctamente");
					$scope.pro.instanciar(true);
				});
			}
		};
		
		$scope.pro.versionarCargar = function(index){
			$scope.pro.cargado.VER_COD_PROYECTO = $scope.data.PROYECTOS[index].COD_PROYECTO;
			$scope.pro.versiones = $scope.data.PROYECTOS[index].versiones;
			$scope.pro.vista = 'versionar';
		};
				
		$scope.pro.validarVersion = function(){
			for(var i in $scope.pro.versiones){
				var ver = $scope.pro.versiones[i];
				if(ver.codigoUnidadNegocio==$scope.pro.cargado.VER_codigoUnidadNegocio){
					$scope.pro.cargado.VER_COD_VERSION = Number(ver.numeroVersion)+1;
					return;
				}
			}
			$scope.pro.cargado.VER_COD_VERSION = 1;
		};
		
		$scope.pro.versionar = function(index){
			$scope.pro.cargado.metodo = "versionar";
			Core.jpo($http,$scope.pro.cargado,function(respuesta){
				$scope.agregarAlerta("success","Versión creada corréctamente");
				$scope.pro.instanciar(true);
			});
		};
		
	});
	
	principal.controller("trabajarProyecto", function($scope, $http) { // trp

		$scope.trp = {
			tab : [
				{ active : false  },
				{ active : false },
				{ active : false },
				{ active : true },
				{ active : false }
			]
		};
		
		$scope.trp.cerrar = function(){
			$scope.$parent.data.PROYECTO = {esCargado : false};
			$scope.$parent.modulo = "proyecto";
			$scope.$parent.subModulo = "";
		};
		
		$scope.trp.generar = function(){
			$scope.$parent.subModulo = "generar";
		};
		
	});
	
	principal.controller("proyectoActual", function($scope, $http, $timeout) { // conproy - conusua
	
		$scope.pra = {};
		$scope.conproy = {};
		$scope.conusua = {};
		
		$scope.pra.instanciar = function(listar){
			$scope.conproy.cargado = {
				paquete : "modulo", modulo : "Administracion", metodo : "editar",
				CON_W_COD_PROYECTO		: $scope.data.PROYECTO.COD_PROYECTO,
				CON_COD_PROYECTO			: $scope.data.PROYECTO.COD_PROYECTO,
				CON_empresa					: $scope.data.CONFIGURACION.empresa,
				CON_unidadNegocio			: $scope.data.CONFIGURACION.unidadNegocio,
				CON_unidadNegocioDescripcion: $scope.data.CONFIGURACION.unidadNegocioDescripcion,
				CON_producto				: $scope.data.CONFIGURACION.producto,
				CON_productoDescripcion		: $scope.data.CONFIGURACION.productoDescripcion,
				CON_urlPrefijoPaquete		: $scope.data.CONFIGURACION.urlPrefijoPaquete,
				CON_directorioWebAuto		: $scope.data.CONFIGURACION.directorioLib,
				CON_directorioEJBAuto		: $scope.data.CONFIGURACION.directorioEJBClient,
				CON_directorioEJBClient		: $scope.data.CONFIGURACION.directorioEJBAuto,
				CON_directorioLib			: $scope.data.CONFIGURACION.directorioWebAuto
			};
			$scope.conusua.cargado = {
				paquete : "modulo", modulo : "Proyecto", metodo : "editarEquipo", 
				EQU_W_COD_PROYECTO		: $scope.data.PROYECTO.COD_PROYECTO,
				EQU_W_COD_USUARIO			: $scope.data.USUARIO.COD_USUARIO,
				EQU_CARPETA_DESTINO_WORKSPACE : $scope.data.EQUIPO.CARPETA_DESTINO_WORKSPACE,
				EQU_CARPETA_DESTINO_PARCIAL	: $scope.data.EQUIPO.CARPETA_DESTINO_PARCIAL
			};
		};
	
		$scope.conproy.guardar = function(){
			Core.jpo($http,$scope.conproy.cargado,function(respuesta){
				$scope.agregarAlerta("success","Datos del Proyecto actualizado corréctamente");
			});
		};
		
		$scope.conusua.guardar = function(){
			Core.jpo($http,$scope.conusua.cargado,function(respuesta){
				$scope.agregarAlerta("success","Configuración Personal actualizada corréctamente");
			});
		};
		
	});
	
	principal.controller("esquema", function($scope, $http) { // esq
		
		$scope.esq = {};
		
		$scope.esq.instanciar = function(listar){
			$scope.esq.cargado = { paquete : "modulo", modulo : "Esquema"};
			$scope.esq.cargado.PRO_W_COD_PROYECTO = $scope.data.PROYECTO.COD_PROYECTO;
			$scope.esq.cargado.PRO_COD_PROYECTO = $scope.data.PROYECTO.COD_PROYECTO;
			$scope.esq.esEdicion = false;
			if(typeof(listar)!="undefined"){
				if(listar){
					$scope.esq.listar();
				}
			}
		};
		
		$scope.esq.listar = function(){
			$scope.esq.cargado.metodo = "listar";
			Core.jpo($http,$scope.esq.cargado,function(respuesta){
				$scope.$parent.data.Esquema = respuesta;
			});
		};
		
		$scope.esq.eliminar = function(index){
			if(confirm("Desea eliminar el esquema seleccionado?")){
				$scope.esq.cargado.metodo = "eliminar";
				$scope.esq.cargado.PRO_W_codigoEsquema = $scope.data.Esquema[index].codigoEsquema;	// WHERE-------
				Core.jpo($http,$scope.esq.cargado,function(respuesta){
					delete $scope.esq.cargado.PRO_W_codigoEsquema;									// WHERE-------
					$scope.agregarAlerta("success","Esquema eliminado corréctamente");
					$scope.esq.instanciar(true);
				});
			}
		};
		
		$scope.esq.editarCargar = function(index){
			$scope.esq.cargado.PRO_codigoEsquema = $scope.data.Esquema[index].codigoEsquema;		// VAL-------
			$scope.esq.cargado.PRO_descripcion = $scope.data.Esquema[index].descripcion;			// VAL-------
			$scope.esq.cargado.PRO_estado = $scope.data.Esquema[index].estado;						// VAL-------
			$scope.esq.esEdicion = true;
		};
		
		$scope.esq.guardar = function(){
			if($scope.esq.esEdicion){
				$scope.esq.cargado.metodo = "editar";
				$scope.esq.cargado.PRO_W_codigoEsquema = $scope.esq.cargado.PRO_codigoEsquema;	// WHERE-------
				Core.jpo($http,$scope.esq.cargado,function(respuesta){
					delete $scope.esq.cargado.PRO_W_codigoEsquema;									// WHERE-------
					$scope.agregarAlerta("success","Esquema editado corréctamente");
					$scope.esq.instanciar(true);
				});
			} else {
				$scope.esq.cargado.metodo = "registrar";
				Core.jpo($http,$scope.esq.cargado,function(respuesta){
					$scope.agregarAlerta("success","Esquema creado corréctamente");
					$scope.esq.instanciar(true);
				});
			}
		};
		
	});
	
	principal.controller("dataSource", function($scope, $http) {

		$scope.dso = {};
		
		$scope.dso.instanciar = function(listar){
			$scope.dso.cargado = { paquete : "modulo", modulo : "DataSource"};
			$scope.dso.cargado.DSO_W_COD_PROYECTO = $scope.data.PROYECTO.COD_PROYECTO;
			$scope.dso.cargado.DSO_COD_PROYECTO = $scope.data.PROYECTO.COD_PROYECTO;
			$scope.dso.esEdicion = false;
			if(typeof(listar)!="undefined"){
				if(listar){
					$scope.dso.listar();
				}
			}
		};
		
		$scope.dso.listar = function(){
			$scope.dso.cargado.metodo = "listar";
			Core.jpo($http,$scope.dso.cargado,function(respuesta){
				$scope.$parent.data.DataSource = respuesta;
			});
		};
		
		$scope.dso.eliminar = function(index){
			if(confirm("Desea eliminar el Data Source seleccionado?")){
				$scope.dso.cargado.metodo = "eliminar";
				$scope.dso.cargado.DSO_W_codigoDataSource = $scope.data.DataSource[index].codigoDataSource;	// WHERE-------
				Core.jpo($http,$scope.dso.cargado,function(respuesta){
					delete $scope.dso.cargado.DSO_W_codigoDataSource;										// WHERE-------
					$scope.agregarAlerta("success","Data Source eliminado corréctamente");
					$scope.dso.instanciar(true);
				});
			}
		};
		
		$scope.dso.editarCargar = function(index){
			$scope.dso.cargado.DSO_codigoDataSource = $scope.data.DataSource[index].codigoDataSource;	// VAL-------
			$scope.dso.cargado.DSO_descripcion = $scope.data.DataSource[index].descripcion;				// VAL-------
			$scope.dso.cargado.DSO_estado = $scope.data.DataSource[index].estado;						// VAL-------
			$scope.dso.esEdicion = true;
		};
		
		$scope.dso.guardar = function(){
			if($scope.dso.esEdicion){
				$scope.dso.cargado.metodo = "editar";
				$scope.dso.cargado.DSO_W_codigoDataSource = $scope.dso.cargado.DSO_codigoDataSource;	// WHERE-------
				Core.jpo($http,$scope.dso.cargado,function(respuesta){
					delete $scope.dso.cargado.DSO_W_codigoDataSource;									// WHERE-------
					$scope.agregarAlerta("success","Data Source editado corréctamente");
					$scope.dso.instanciar(true);
				});
			} else {
				$scope.dso.cargado.metodo = "registrar";
				Core.jpo($http,$scope.dso.cargado,function(respuesta){
					$scope.agregarAlerta("success","Data Source creado corréctamente");
					$scope.dso.instanciar(true);
				});
			}
		};
		
	});
	
	principal.controller("rol", function($scope, $http) {

		$scope.rol = {};
		
		$scope.rol.instanciar = function(listar){
			$scope.rol.cargado = { paquete : "modulo", modulo : "Rol"};
			$scope.rol.cargado.ROL_W_COD_PROYECTO = $scope.data.PROYECTO.COD_PROYECTO;
			$scope.rol.cargado.ROL_COD_PROYECTO = $scope.data.PROYECTO.COD_PROYECTO;
			$scope.rol.esEdicion = false;
			if(typeof(listar)!="undefined"){
				if(listar){
					$scope.rol.listar();
				}
			}
		};
		
		$scope.rol.listar = function(){
			$scope.rol.cargado.metodo = "listar";
			Core.jpo($http,$scope.rol.cargado,function(respuesta){
				$scope.$parent.data.Rol = respuesta;
			});
		};
		
		$scope.rol.eliminar = function(index){
			if(confirm("Desea eliminar el Rol seleccionado?")){
				$scope.rol.cargado.metodo = "eliminar";
				$scope.rol.cargado.ROL_W_codigoRol = $scope.data.Rol[index].codigoRol;			// WHERE-------
				Core.jpo($http,$scope.rol.cargado,function(respuesta){
					delete $scope.rol.cargado.ROL_W_codigoRol;									// WHERE-------
					$scope.agregarAlerta("success","Rol eliminado corréctamente");
					$scope.rol.instanciar(true);
				});
			}
		};
		
		$scope.rol.editarCargar = function(index){
			$scope.rol.cargado.ROL_codigoRol = $scope.data.Rol[index].codigoRol;				// VAL-------
			$scope.rol.cargado.ROL_descripcion = $scope.data.Rol[index].descripcion;			// VAL-------
			$scope.rol.cargado.ROL_estado = $scope.data.Rol[index].estado;						// VAL-------
			$scope.rol.esEdicion = true;
		};
		
		$scope.rol.guardar = function(){
			if($scope.rol.esEdicion){
				$scope.rol.cargado.metodo = "editar";
				$scope.rol.cargado.ROL_W_codigoRol = $scope.rol.cargado.ROL_codigoRol;			// WHERE-------
				Core.jpo($http,$scope.rol.cargado,function(respuesta){
					delete $scope.rol.cargado.ROL_W_codigoRol;									// WHERE-------
					$scope.agregarAlerta("success","Rol editado corréctamente");
					$scope.rol.instanciar(true);
				});
			} else {
				$scope.rol.cargado.metodo = "registrar";
				Core.jpo($http,$scope.rol.cargado,function(respuesta){
					$scope.agregarAlerta("success","Rol creado corréctamente");
					$scope.rol.instanciar(true);
				});
			}
		};
		
	});
	
	principal.controller("entidad", function($scope, $http) {

		$scope.ent = {};
		$scope.ent.mostrar = true;
		$scope.ent.pag = {
			actual : 1,
			itemxPagina : 5,
			max : 5,
			get : function(ind){
				return Math.floor(ind/this.itemxPagina) + 1;
			}
		};
		
		$scope.ent.instanciar = function(listar){
			$scope.ent.cargado = { paquete : "modulo", modulo : "Clase"};
			$scope.ent.cargado.CLA_W_COD_PROYECTO = $scope.data.PROYECTO.COD_PROYECTO;
			$scope.ent.cargado.CLA_COD_PROYECTO = $scope.data.PROYECTO.COD_PROYECTO;

			//$scope.ent.cargado.CLA_java_esEntidad = 1;
			$scope.ent.esEdicion = false;
			$scope.ent.pag.total = $scope.data.CLASE.length;
			
			if(typeof(listar)!="undefined"){
				if(listar){
					$scope.ent.listar();
				}
			}
		};
		
		$scope.ent.listar = function(){
			$scope.ent.cargado.metodo = "listar";
			Core.jpo($http,$scope.ent.cargado,function(respuesta){
				$scope.$parent.data.CLASE = respuesta;
			});
		};
		
		$scope.ent.eliminar = function(index){
			if(confirm("Desea eliminar la Entidad seleccionada?")){
				$scope.ent.cargado.metodo = "eliminar";
				$scope.ent.cargado.ATR_W_COD_CLASE = $scope.data.CLASE[index].COD_CLASE;		// WHERE-------
				$scope.ent.cargado.CLA_W_COD_CLASE = $scope.data.CLASE[index].COD_CLASE;		// WHERE-------
				Core.jpo($http,$scope.ent.cargado,function(respuesta){
					delete $scope.ent.cargado.CLA_W_COD_CLASE;									// WHERE-------
					$scope.agregarAlerta("success","Entidad eliminado corréctamente");
					$scope.ent.instanciar(true);
				});
			}
		};
		
		$scope.ent.editarCargar = function(index){
			$scope.ent.cargado.CLA_COD_CLASE = $scope.data.CLASE[index].COD_CLASE;					// VAL-------
			$scope.ent.cargado.CLA_NOMBRE = $scope.data.CLASE[index].NOMBRE;						// VAL-------
			$scope.ent.cargado.CLA_PAQUETE = $scope.data.CLASE[index].PAQUETE;
			$scope.ent.cargado.CLA_NIVEL = $scope.data.CLASE[index].NIVEL;
			$scope.ent.esEdicion = true;
		};
		
		$scope.ent.guardar = function(){
			if($scope.ent.esEdicion){
				$scope.ent.cargado.metodo = "editar";
				$scope.ent.cargado.CLA_W_COD_CLASE = $scope.ent.cargado.CLA_COD_CLASE;			// WHERE-------
				Core.jpo($http,$scope.ent.cargado,function(respuesta){
					delete $scope.ent.cargado.CLA_W_COD_CLASE;									// WHERE-------
					$scope.agregarAlerta("success","Entidad editado corréctamente");
					$scope.ent.instanciar(true);
				});
			} else {
				$scope.ent.cargado.metodo = "registrar";
				Core.jpo($http,$scope.ent.cargado,function(respuesta){
					$scope.agregarAlerta("success","Entidad creado corréctamente");
					$scope.ent.instanciar(true);
				});
			}
		};
		
		$scope.ent.asignarFormato = function(){
			var formatos = f_formato.getClases($scope.ent.cargado.CLA_COD_CLASE);
			$scope.ent.cargado.java_entidad = formatos[0];
			$scope.ent.cargado.proceso_entidad = formatos[1];
			$scope.ent.cargado.bds_entidad = formatos[2];
		};
		
		$scope.ent.gestionarAtributos = function(index){
			$scope.ent.mostrar = false;
			
			angular.element(document.querySelector('[ng-controller=atributo]')).scope().atr.instanciar($scope.data.CLASE[index].COD_CLASE);
		};
		
	});
	
	principal.controller("atributo", function($scope, $http) {

		$scope.atr = {};
		$scope.atr.Atributo = [];
		$scope.atr.mostrar = true;
		$scope.atr.pag = {
			actual : 1,
			itemxPagina : 5,
			max : 5,
			get : function(ind){
				return Math.floor(ind/this.itemxPagina) + 1;
			}
		};
		$scope.atr.COD_CLASE = "";
		$scope.atr.instanciar = function(codigoClase){
			if(codigoClase){
				$scope.atr.COD_CLASE = codigoClase;
			} else {
				codigoClase = $scope.atr.COD_CLASE;
			}
			$scope.atr.cargado = { paquete : "modulo", modulo : "Atributo"};
			$scope.atr.cargado.ATR_W_COD_PROYECTO = $scope.data.PROYECTO.COD_PROYECTO;
			$scope.atr.cargado.ATR_COD_PROYECTO = $scope.data.PROYECTO.COD_PROYECTO;
			$scope.atr.cargado.ATR_W_COD_VERSION = $scope.data.PROYECTO.versionSeleccionada;
			$scope.atr.cargado.ATR_COD_VERSION = $scope.data.PROYECTO.versionSeleccionada;
			$scope.atr.cargado.ATR_W_codigoUnidadNegocio = $scope.data.PROYECTO.unidadNegocioSeleccionado;
			$scope.atr.cargado.ATR_codigoUnidadNegocio = $scope.data.PROYECTO.unidadNegocioSeleccionado;
			$scope.atr.cargado.ATR_W_COD_CLASE = codigoClase;
			$scope.atr.cargado.ATR_COD_CLASE = codigoClase;
			$scope.atr.esEdicion = false;
			$scope.atr.listar();
		};
		
		$scope.atr.listar = function(){
			$scope.atr.cargado.metodo = "listar";
			Core.jpo($http,$scope.atr.cargado,function(respuesta){
				$scope.atr.Atributo = respuesta;
				$scope.atr.pag.total = respuesta.length;
			});
		};
		
		$scope.atr.eliminar = function(index){
			if(confirm("Desea eliminar la Entidad seleccionada?")){
				$scope.atr.cargado.metodo = "eliminar";
				$scope.atr.cargado.ATR_W_COD_CLASE = $scope.data.CLASE[index].COD_CLASE;		// WHERE-------
				Core.jpo($http,$scope.atr.cargado,function(respuesta){
					delete $scope.atr.cargado.ATR_W_COD_CLASE;									// WHERE-------
					$scope.agregarAlerta("success","Entidad eliminado corréctamente");
					$scope.atr.instanciar(true);
				});
			}
		};
		
		$scope.atr.editarCargar = function(index){
			$scope.atr.cargado.CLA_COD_CLASE = $scope.data.CLASE[index].COD_CLASE;					// VAL-------
			$scope.atr.cargado.CLA_NOMBRE = $scope.data.CLASE[index].NOMBRE;						// VAL-------
			$scope.atr.cargado.CLA_PAQUETE = $scope.data.CLASE[index].PAQUETE;
			$scope.atr.cargado.CLA_NIVEL = $scope.data.CLASE[index].NIVEL;
			$scope.atr.esEdicion = true;
		};
		
		$scope.atr.guardar = function(){
			if($scope.atr.esEdicion){
				$scope.atr.cargado.metodo = "editar";
				$scope.atr.cargado.ATR_W_COD_CLASE = $scope.atr.cargado.ATR_COD_CLASE;			// WHERE-------
				Core.jpo($http,$scope.atr.cargado,function(respuesta){
					delete $scope.atr.cargado.ATR_W_COD_CLASE;									// WHERE-------
					$scope.agregarAlerta("success","Entidad editado corréctamente");
					$scope.atr.instanciar(true);
				});
			} else {
				$scope.atr.cargado.metodo = "registrar";
				Core.jpo($http,$scope.atr.cargado,function(respuesta){
					$scope.agregarAlerta("success","Entidad creado corréctamente");
					$scope.atr.instanciar(true);
				});
			}
		};
		
		$scope.atr.asignarFormato = function(){
			var formatos = f_formato.getClases($scope.atr.cargado.CLA_COD_CLASE);
			$scope.atr.cargado.java_entidad = formatos[0];
			$scope.atr.cargado.proceso_entidad = formatos[1];
			$scope.atr.cargado.bds_entidad = formatos[2];
		};
		
		$scope.atr.gestionarAtributos = function(){
			
		};
		
	});

	principal.controller("proceso", function($scope, $http) {

		$scope.pra = {
		};
		
	});
	
	principal.controller("mantenimiento", function($scope, $http) {

		$scope.man = {};
		
		$scope.man.atributos = [];
		$scope.man.vista = "mantener"; // lista - mantener
		
		$scope.man.TipoDatos = [
			{	id : "long"			, valor : "long - BIGINT"},
			{	id : "String"		, valor : "String - VARCHAR"},
			{	id : "BigDecimal"	, valor : "java.math.BigDecimal - DECIMAL"},
			{	id : "double"		, valor : "double - DECIMAL"},
			{	id : "Date"			, valor : "Date - DATE"},
			{	id : "boolean"		, valor : "boolean - CHAR"},
			{	id : "Timestamp"	, valor : "java.sql.Timestamp - TIMESTAMP"},
			{	id : "int"			, valor : "int - INTEGER"}
		];
		
		$scope.man.instanciar = function(listar){
			$scope.man.vista = "lista";
			$scope.man.cargado = { paquete : "modulo", modulo : "Mantenimiento"};
			$scope.man.esEdicion = false;
			if(typeof(listar)!="undefined"){
				if(listar){
					$scope.man.listar();
				}
			}
		};
		
		$scope.man.listar = function(){
			$scope.man.cargado.metodo = "listar";
			Core.jpo($http,$scope.man.cargado,function(respuesta){
				$scope.$parent.data.Mantenimiento = respuesta;
			});
		};
		
		$scope.man.eliminar = function(index){
			var codMantenimiento;
			if(typeof(index)=="undefined" && typeof($scope.man.cargado.MAN_COD_MANTENIMIENTO)!="undefined"){
				codMantenimiento = $scope.man.cargado.MAN_COD_MANTENIMIENTO;
			} else {
				codMantenimiento = $scope.$parent.data.Mantenimiento[index].codigoMantenimiento;
			}
			if(confirm("Desea eliminar el Mantenimiento seleccionado?")){
				$scope.man.cargado.metodo = "eliminar";
				$scope.man.cargado["MAN_W_COD_PROYECTO"] = $scope.data.PROYECTO.COD_PROYECTO;
				$scope.man.cargado["MAN_W_COD_VERSION"] = $scope.data.PROYECTO.versionSeleccionada;
				$scope.man.cargado["MAN_W_COD_MANTENIMIENTO"] = codMantenimiento;
				Core.jpo($http,$scope.man.cargado,function(respuesta){
					delete $scope.man.cargado.USU_W_COD_USUARIO;									// WHERE-------
					$scope.agregarAlerta("success","Mantenimiento eliminado corréctamente");
					$scope.man.instanciar(true);
				});
			}
		};
		
		$scope.man.nuevo = function(index){
			$scope.man.vista = "mantener";
			$scope.man.esEdicion = false;
			$scope.man.atributos = [];
		};
		
		$scope.man.editarCargar = function(index){
			$scope.man.cargado.metodo = "editarCargar";
			
			$scope.man.cargado["MAN_W_COD_PROYECTO"] = $scope.data.PROYECTO.COD_PROYECTO;
			$scope.man.cargado["MAN_W_COD_VERSION"] = $scope.data.PROYECTO.versionSeleccionada;
			$scope.man.cargado["MAN_W_COD_MANTENIMIENTO"] = $scope.$parent.data.Mantenimiento[index].codigoMantenimiento;
			
			$scope.man.cargado["MRO_W_COD_PROYECTO"] = $scope.data.PROYECTO.COD_PROYECTO;
			$scope.man.cargado["MRO_W_COD_VERSION"] = $scope.data.PROYECTO.versionSeleccionada;
			$scope.man.cargado["MRO_W_COD_MANTENIMIENTO"] = $scope.$parent.data.Mantenimiento[index].codigoMantenimiento;
			
			$scope.man.cargado["AMA_W_COD_PROYECTO"] = $scope.data.PROYECTO.COD_PROYECTO;
			$scope.man.cargado["AMA_W_COD_VERSION"] = $scope.data.PROYECTO.versionSeleccionada;
			$scope.man.cargado["AMA_W_COD_MANTENIMIENTO"] = $scope.$parent.data.Mantenimiento[index].codigoMantenimiento;
			
			Core.jpo($http,$scope.man.cargado,function(respuesta){
				$scope.man.vista = "mantener";
				$scope.man.esEdicion = true;
				
				$scope.man.cargado.MAN_COD_PROYECTO = respuesta.mantenimiento.COD_PROYECTO;
				$scope.man.cargado.MAN_COD_VERSION = respuesta.mantenimiento.numeroVersion;
				$scope.man.cargado.MAN_COD_MANTENIMIENTO = respuesta.mantenimiento.codigoMantenimiento;
				$scope.man.cargado.MAN_nombre = respuesta.mantenimiento.nombre;
				$scope.man.cargado.MAN_descripcion = respuesta.mantenimiento.descripcion;
				$scope.man.cargado.MAN_codigoEsquema = respuesta.mantenimiento.codigoEsquema;
				$scope.man.cargado.MAN_codigoDataSource =  respuesta.mantenimiento.codigoDataSource;
				
				$scope.man.cargado.MRO_codigoRoles = [];
				for(var i = 0; i<respuesta.MantenimientoRoles.length; i++){
					$scope.man.cargado.MRO_codigoRoles.push(respuesta.MantenimientoRoles[i].codigoRol);
				}
				
				$scope.man.atributos = respuesta.mantenimientoAtributo;
			});
			
		};
		
		$scope.man.validarDatos = function(){
			var respuesta = reglaMapeo([
				{valor : $scope.man.cargado.MAN_COD_MANTENIMIENTO, 	regla : "REQUERIDO", mensaje : "Ingrese un código de mantenimiento"},
				{valor : $scope.man.cargado.MAN_codigoEsquema, 			regla : "REQUERIDO", mensaje : "Seleccione un esquema"},
				{valor : $scope.man.cargado.MAN_codigoDataSource, 		regla : "REQUERIDO", mensaje : "Seleccione un datasource"},
				{valor : $scope.man.cargado.MRO_codigoRoles, 			regla : "REQUERIDO", mensaje : "Seleccione uno o más roles"}
			]);
			if(respuesta.resultado){
				if($scope.man.atributos.length==0){
					$scope.agregarAlerta("danger","Debe ingresar uno o más atributos");
					return false;
				} else {
					var reglasAtributos = [];
					var tieneLLave = 0;
					for(var i = 0; i<$scope.man.atributos.length; i++){
						reglasAtributos.push({
							valor: $scope.man.atributos[i].nombre,
							regla: "REQUERIDO",
							mensaje: "Ingrese un nombre de campo correcto a la fila "+(Number(i)+1)
						});
						reglasAtributos.push({
							valor: $scope.man.atributos[i].descripcion,
							regla: "REQUERIDO",
							mensaje: "Ingrese una descripción de campo correcto a la fila "+(Number(i)+1)
						});
						reglasAtributos.push({
							valor: $scope.man.atributos[i].tipoDato,
							regla: "REQUERIDO",
							mensaje: "Seleccione un tipo de dato correcto a la fila "+(Number(i)+1)
						});
						var tipoDato = $scope.man.atributos[i].tipoDato;
						if(tipoDato == 'long' || tipoDato == 'Date' || tipoDato == 'int' || tipoDato == 'Timestamp'){
							
						} else {
							reglasAtributos.push({
								valor: $scope.man.atributos[i].longitud,
								regla: "ENTERO",
								mensaje: "Ingrese una longitud correcta a la fila "+(Number(i)+1)
							});
							if(tipoDato == 'BigDecimal' || tipoDato == 'double'){
								reglasAtributos.push({
									valor: $scope.man.atributos[i].precision,
									regla: "ENTERO",
									mensaje: "Ingrese una precision correcta a la fila "+(Number(i)+1)
								});
							}
						}
						if($scope.man.atributos[i].esLlavePrimaria == true){
							tieneLLave++;
						}
					}
					var respuesta = reglaMapeo(reglasAtributos);
					if(respuesta.resultado){
						if(tieneLLave == 0){
							$scope.agregarAlerta("danger","Debe agregar por lo menos una llave primaria");
						} else {
							return true;
						}
					} else {
						$scope.agregarAlerta("danger",respuesta.mensaje);
						return false;
					}
				}
			} else {
				$scope.agregarAlerta("danger",respuesta.mensaje);
				return false;
			}
		};
		
		$scope.man.guardar = function(){
			if($scope.man.validarDatos()){
			
				$scope.man.cargado.registrarTodo = true;
				$scope.man.cargado["MAN_COD_PROYECTO"] = $scope.data.PROYECTO.COD_PROYECTO;
				$scope.man.cargado["MAN_COD_VERSION"] = $scope.data.PROYECTO.versionSeleccionada;
				
				for(var i = 0; i<$scope.man.atributos.length; i++){
					var atri = $scope.man.atributos[i];
					$scope.man.cargado["AMA_M_"+(Number(i)+1)+"_COD_PROYECTO"] = $scope.data.PROYECTO.COD_PROYECTO;
					$scope.man.cargado["AMA_M_"+(Number(i)+1)+"_COD_VERSION"] = $scope.data.PROYECTO.versionSeleccionada;
					$scope.man.cargado["AMA_M_"+(Number(i)+1)+"_COD_MANTENIMIENTO"] = $scope.man.cargado.MAN_COD_MANTENIMIENTO;
					$scope.man.cargado["AMA_M_"+(Number(i)+1)+"_codigoAtributo"] = (Number(i)+1);
					$scope.man.cargado["AMA_M_"+(Number(i)+1)+"_nombre"] = atri.nombre;
					$scope.man.cargado["AMA_M_"+(Number(i)+1)+"_descripcion"] = atri.descripcion;
					$scope.man.cargado["AMA_M_"+(Number(i)+1)+"_tipoDato"] = atri.tipoDato;
					if(atri.longitud){
						$scope.man.cargado["AMA_M_"+(Number(i)+1)+"_longitud"] = atri.longitud;
					}
					if(atri.precision){
						$scope.man.cargado["AMA_M_"+(Number(i)+1)+"_precision"] = atri.precision;
					}
					$scope.man.cargado["AMA_M_"+(Number(i)+1)+"_esLlavePrimaria"] = atri.esLlavePrimaria?"1":"0";
					$scope.man.cargado["AMA_M_"+(Number(i)+1)+"_esListado"] = atri.esListado?"1":"0";
					$scope.man.cargado["AMA_M_"+(Number(i)+1)+"_esBusqueda"] = atri.esBusqueda?"1":"0";
					$scope.man.cargado["AMA_M_"+(Number(i)+1)+"_esObligatorio"] = atri.esObligatorio?"1":"0";
				}
				for(var i = 0; i<$scope.man.cargado.MRO_codigoRoles.length; i++){
					var rol = $scope.man.cargado.MRO_codigoRoles[i];
					$scope.man.cargado["MRO_M_"+(Number(i)+1)+"_COD_PROYECTO"] = $scope.data.PROYECTO.COD_PROYECTO;
					$scope.man.cargado["MRO_M_"+(Number(i)+1)+"_COD_VERSION"] = $scope.data.PROYECTO.versionSeleccionada;
					$scope.man.cargado["MRO_M_"+(Number(i)+1)+"_COD_MANTENIMIENTO"] = $scope.man.cargado.MAN_COD_MANTENIMIENTO;
					$scope.man.cargado["MRO_M_"+(Number(i)+1)+"_codigoRol"] = rol;
				}
				
				if($scope.man.esEdicion){
					
					$scope.man.cargado["MAN_W_COD_PROYECTO"] = $scope.data.PROYECTO.COD_PROYECTO;
					$scope.man.cargado["MAN_W_COD_VERSION"] = $scope.data.PROYECTO.versionSeleccionada;
					$scope.man.cargado["MAN_W_COD_MANTENIMIENTO"] = $scope.man.cargado.MAN_COD_MANTENIMIENTO;
					
					$scope.man.cargado["MRO_W_COD_PROYECTO"] = $scope.data.PROYECTO.COD_PROYECTO;
					$scope.man.cargado["MRO_W_COD_VERSION"] = $scope.data.PROYECTO.versionSeleccionada;
					$scope.man.cargado["MRO_W_COD_MANTENIMIENTO"] = $scope.man.cargado.MAN_COD_MANTENIMIENTO;
					
					$scope.man.cargado["AMA_W_COD_PROYECTO"] = $scope.data.PROYECTO.COD_PROYECTO;
					$scope.man.cargado["AMA_W_COD_VERSION"] = $scope.data.PROYECTO.versionSeleccionada;
					$scope.man.cargado["AMA_W_COD_MANTENIMIENTO"] = $scope.man.cargado.MAN_COD_MANTENIMIENTO;
					
					$scope.man.cargado.metodo = "editar";
					Core.jpo($http,$scope.man.cargado,function(respuesta){
						$scope.agregarAlerta("success","Mantenimiento editado corréctamente");
						$scope.man.instanciar(true);
					});
				} else {
					$scope.man.cargado.metodo = "registrar";
					Core.jpo($http,$scope.man.cargado,function(respuesta){
						$scope.agregarAlerta("success","Mantenimiento Agregado Corréctamente");
						$scope.man.instanciar(true);
					});
				}
			}
		};
		
		/* ATRIBUTOS */
		$scope.man.atributoAgregar = function(){
			$scope.man.atributos.push({});
		};
		
		$scope.man.atributoEliminar = function($index){
			$scope.man.atributos.splice($index,1);
		};
		
		$scope.man.atributoSubir = function($index){
			if($index>0){
				$scope.man.atributos.move($index-1,$index);
			}
		};
		
		$scope.man.atributoBajar = function($index){
			if($index<$scope.man.atributos.length-1){
				$scope.man.atributos.move($index,$index+1);
			}
		};
		
		$scope.man.atributoCopiar = function($index){
			$scope.man.atributos.push(angular.copy($scope.man.atributos[$index]));
		};
		
		$scope.man.atributoValidarLLave = function($index){
			if($scope.man.atributos[$index].esLlavePrimaria == true){
				$scope.man.atributos[$index].esObligatorio = true;
			}
		};
		
		$scope.man.atributoValidarBusqueda = function($index){
			if($scope.man.atributos[$index].esBusqueda == true){
				$scope.man.atributos[$index].esListado = true;
			}
		};
		
	});
	
	principal.controller("reporte", function($scope, $http) {

		$scope.pra = {
		};
		
	});
	
	principal.controller("generar", function($scope, $http) {

		$scope.pra = {
		};
		
	});
	
	principal.controller('Modal_generar', function ($scope, $modalInstance, config) {

		$scope.data = config.data;
		
		$scope.cancelar = function(){
			$modalInstance.close();
		};
		
		$scope.salir = function(){
			$modalInstance.dismiss('cancel');
		};
		
	});
	
	principal.directive('alertas', 			function(){ return {restrict: 'E', templateUrl: 'Alertas.html'}; 			});
	principal.directive('gestionarUsuario', function(){	return {restrict: 'E', templateUrl: 'GestionarUsuario.html'};	});
	principal.directive('gestionarUnidadNegocio', function(){	return {restrict: 'E', templateUrl: 'GestionarUnidadNegocio.html'};		});
	principal.directive('perfilUsuario', function(){	return {restrict: 'E', templateUrl: 'PerfilUsuario.html'};		});
	
	
	principal.directive('gestionarProyecto', function(){	return {restrict: 'E', templateUrl: 'GestionarProyecto.html'};		});
	principal.directive('trabajarProyecto', function(){	return {restrict: 'E', templateUrl: 'TrabajarProyecto.html'};		});
	
		principal.directive('proyectoActual', function(){	return {restrict: 'E', templateUrl: 'ProyectoActual.html',link : function($scope){
				
			}};		});
		principal.directive('entidad', function(){	return {restrict: 'E', templateUrl: 'Entidad.html'};					});
		principal.directive('atributo', function(){	return {restrict: 'E', templateUrl: 'Atributo.html'};					});
		principal.directive('proceso', function(){	return {restrict: 'E', templateUrl: 'Proceso.html'};					});
		principal.directive('mantenimiento', function(){	return {restrict: 'E', templateUrl: 'Mantenimiento.html'};		});
		principal.directive('reporte', function(){	return {restrict: 'E', templateUrl: 'Reporte.html'};					});
		principal.directive('esquema', function(){	return {restrict: 'E', templateUrl: 'Esquema.html'};					});
		principal.directive('datasource', function(){	return {restrict: 'E', templateUrl: 'DataSource.html'};				});
		principal.directive('rol', function(){	return {restrict: 'E', templateUrl: 'Rol.html'};							});
		principal.directive('generar', function(){	return {restrict: 'E', templateUrl: 'Generar.html'};					});
		
	principal.constant('paginationConfig', {
		boundaryLinks: false,
		directionLinks: true,
		firstText: 'Primero',
		previousText: '<',
		nextText: '>',
		lastText: 'Ultimo'
	});

	var f_formato = {
		formatoMayus : function(texto){
			return texto.substring(0,1).toUpperCase()+texto.substring(1,texto.length).toLowerCase(); 
		},
		getClases : function(nombre){
			if(nombre){
				var palabras = nombre.split(" ");
				var java = "",proceso = "", bd = "";
				for(var i = 0; i < palabras.length; i++){
					java +=this.formatoMayus(palabras[i]);
					proceso += palabras[i].toLowerCase();
					bd += palabras[i].toUpperCase()+"_";
				}
				return [java,proceso,bd.substring(0,bd.length-1)];
			} else {
				return ["","",""];
			}
		}	
	};